import { Component } from '@angular/core';

@Component({
  selector: 'app-server',
  templateUrl: './server.component.html',
  styles: [`
    .online {
      color: yellow;
    }
    .offline {
      color: blue;
    }
  `]
})
export class ServerComponent {
  serverId: number = 10;
  serverStatus: string = 'offline';
  randomNumber: number;
  constructor() {
    this.randomNumber = Math.random();
    (this.randomNumber >= 0.5) ? this.serverStatus = 'online' : this.serverStatus = 'offline';
    console.log(this.randomNumber);
  }

  getServerStatus() {
    return this.serverStatus;
  }

  getColor() {
    return this.serverStatus === 'online' ? 'green' : 'red';
  }
}
